# Calculator App

This project was created using react and includes functional compoments , state hooks and much more.

![image](https://user-images.githubusercontent.com/45850768/153692898-9bbfc911-ee5c-4d18-832c-d277445cb25b.png)

